["Mascott", "Tux", "OS", "Linux"]
